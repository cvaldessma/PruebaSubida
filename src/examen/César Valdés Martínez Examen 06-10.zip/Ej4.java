package examen;

public class Ej4 {

	public static void main(String[] args) {
		//Escribir todos los n�meros del 100 al 0 de 5 en 5
		for (int i = 100; i>=0; i=i-5) {
			System.out.println(i);
		}
	}
}
